Download and install ciefpsettings motor from GitHub
